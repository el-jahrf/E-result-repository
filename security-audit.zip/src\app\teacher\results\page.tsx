import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import ResultEntryForm from "./ResultEntryForm";

type TeacherResultsPageProps = {
  searchParams: Promise<{
    assignmentId?: string;
  }>;
};

export default async function TeacherResultsPage({
  searchParams,
}: TeacherResultsPageProps) {
  const session = await auth();

  if (!session?.user) {
    redirect("/login");
  }

  if (session.user.role !== "TEACHER") {
    redirect("/");
  }

  const teacherId = session.user.teacherId;

  if (!teacherId) {
    return (
      <main className="min-h-screen bg-gray-50 p-8">
        <div className="mx-auto max-w-2xl rounded-2xl border border-red-200 bg-white p-8 shadow-sm">
          <h1 className="text-xl font-bold text-red-700">
            Teacher profile not found
          </h1>

          <p className="mt-2 text-gray-600">
            Your account is marked as a teacher, but no teacher profile is
            linked to it.
          </p>

          <Link
            href="/teacher"
            className="mt-6 inline-block rounded-lg bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
          >
            Back to Dashboard
          </Link>
        </div>
      </main>
    );
  }

  const { assignmentId } = await searchParams;

  if (!assignmentId) {
    redirect("/teacher");
  }

  const currentSession = await prisma.academicSession.findFirst({
    where: {
      isCurrent: true,
    },
  });

  if (!currentSession) {
    return (
      <main className="min-h-screen bg-gray-50 p-8">
        <div className="mx-auto max-w-2xl rounded-2xl border bg-white p-8 shadow-sm">
          <h1 className="text-xl font-bold text-gray-900">
            No current academic session
          </h1>

          <p className="mt-2 text-gray-600">
            An active academic session needs to be configured before results
            can be entered.
          </p>
        </div>
      </main>
    );
  }

  const assignment = await prisma.teacherAssignment.findFirst({
    where: {
      id: assignmentId,
      teacherId,
      sessionId: currentSession.id,
    },
    include: {
      class: true,
      subject: true,
    },
  });

  if (!assignment) {
    return (
      <main className="min-h-screen bg-gray-50 p-8">
        <div className="mx-auto max-w-2xl rounded-2xl border border-red-200 bg-white p-8 shadow-sm">
          <h1 className="text-xl font-bold text-red-700">
            Assignment not found
          </h1>

          <p className="mt-2 text-gray-600">
            This assignment does not exist, is not part of the current
            academic session, or is not assigned to you.
          </p>

          <Link
            href="/teacher"
            className="mt-6 inline-block rounded-lg bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
          >
            Back to Dashboard
          </Link>
        </div>
      </main>
    );
  }

  const enrollments = await prisma.enrollment.findMany({
    where: {
      classId: assignment.classId,
      sessionId: assignment.sessionId,
      term: assignment.term,
    },
    include: {
      student: true,
    },
    orderBy: {
      student: {
        lastName: "asc",
      },
    },
  });

  const existingResults = await prisma.result.findMany({
    where: {
      classId: assignment.classId,
      subjectId: assignment.subjectId,
      sessionId: assignment.sessionId,
      term: assignment.term,
    },
    select: {
      studentId: true,
      ca1Score: true,
      ca2Score: true,
      caTotal: true,
      examScore: true,
      totalScore: true,
      grade: true,
      remark: true,
      teacherRemark: true,
      status: true,
    },
  });

  const resultMap = new Map(
    existingResults.map((result) => [result.studentId, result]),
  );

  const students = enrollments.map((enrollment) => {
    const result = resultMap.get(enrollment.studentId);

    return {
      studentId: enrollment.studentId,
      admissionNo: enrollment.student.admissionNo,
      name: `${enrollment.student.firstName}${
        enrollment.student.middleName
          ? ` ${enrollment.student.middleName}`
          : ""
      } ${enrollment.student.lastName}`,
      ca1: result?.ca1Score?.toString() ?? "",
      ca2: result?.ca2Score?.toString() ?? "",
      exam: result?.examScore?.toString() ?? "",
      teacherRemark: result?.teacherRemark ?? "",
      status: result?.status ?? "NOT_ENTERED",
    };
  });

  const termLabel =
    assignment.term === "FIRST"
      ? "First Term"
      : assignment.term === "SECOND"
        ? "Second Term"
        : "Third Term";

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-7xl px-6 py-8">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="mb-2 flex items-center gap-2 text-sm text-gray-500">
              <Link href="/teacher" className="hover:text-gray-900">
                Teacher Dashboard
              </Link>

              <span>/</span>

              <span>Result Entry</span>
            </div>

            <h1 className="text-3xl font-bold tracking-tight text-gray-950">
              Result Entry
            </h1>

            <p className="mt-1 text-gray-600">
              Enter student scores and teacher remarks for the assigned
              subject.
            </p>
          </div>

          <Link
            href="/teacher"
            className="inline-flex w-fit items-center rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm hover:bg-gray-50"
          >
            ← Back to Dashboard
          </Link>
        </div>

        <section className="mb-6 rounded-2xl border border-gray-200 bg-white shadow-sm">
          <div className="border-b border-gray-200 px-6 py-5">
            <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-gray-500">
                  Assigned Result
                </p>

                <h2 className="mt-1 text-2xl font-bold text-gray-950">
                  {assignment.subject.name}
                </h2>

                <p className="mt-1 text-sm text-gray-500">
                  {assignment.subject.code}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                <div className="rounded-xl bg-gray-50 px-4 py-3">
                  <p className="text-xs font-medium text-gray-500">Class</p>

                  <p className="mt-1 text-sm font-bold text-gray-900">
                    {assignment.class.name}
                  </p>
                </div>

                <div className="rounded-xl bg-gray-50 px-4 py-3">
                  <p className="text-xs font-medium text-gray-500">Term</p>

                  <p className="mt-1 text-sm font-bold text-gray-900">
                    {termLabel}
                  </p>
                </div>

                <div className="col-span-2 rounded-xl bg-gray-50 px-4 py-3 md:col-span-1">
                  <p className="text-xs font-medium text-gray-500">
                    Academic Session
                  </p>

                  <p className="mt-1 text-sm font-bold text-gray-900">
                    {currentSession.name}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="border-b border-gray-200 px-6 py-5">
            <div className="mb-3">
              <p className="text-sm font-semibold text-gray-900">
                Marking Scheme
              </p>

              <p className="mt-1 text-xs text-gray-500">
                CA contributes 40 marks and examination contributes 60 marks.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3 md:max-w-xl">
              <div className="rounded-xl border border-gray-200 bg-white px-4 py-3">
                <p className="text-xs text-gray-500">CA 1</p>
                <p className="mt-1 text-lg font-bold text-gray-900">20</p>
              </div>

              <div className="rounded-xl border border-gray-200 bg-white px-4 py-3">
                <p className="text-xs text-gray-500">CA 2</p>
                <p className="mt-1 text-lg font-bold text-gray-900">20</p>
              </div>

              <div className="rounded-xl border border-gray-200 bg-white px-4 py-3">
                <p className="text-xs text-gray-500">Examination</p>
                <p className="mt-1 text-lg font-bold text-gray-900">60</p>
              </div>
            </div>
          </div>

          {enrollments.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <h3 className="text-lg font-bold text-gray-900">
                No students enrolled
              </h3>

              <p className="mt-2 text-sm text-gray-500">
                There are currently no students enrolled in this class for
                this term.
              </p>
            </div>
          ) : (
            <ResultEntryForm
              assignmentId={assignment.id}
              students={students}
            />
          )}
        </section>
      </div>
    </main>
  );
}