import Link from "next/link";
import { redirect } from "next/navigation";

import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function getClassLabel(classItem: {
  name: string;
  arm: string | null;
  stream: string | null;
}) {
  const parts = [classItem.name];

  if (classItem.arm) {
    parts.push(classItem.arm);
  }

  if (classItem.stream && classItem.stream !== classItem.arm) {
    parts.push(classItem.stream);
  }

  return parts.join(" ");
}

function isLowerSchool(section: string) {
  return section === "NURSERY" || section === "PRIMARY";
}

export default async function TeacherDashboard() {
  const session = await auth();

  if (!session?.user?.id) {
    redirect("/login");
  }

  if (session.user.role !== "TEACHER") {
    redirect("/");
  }

  const teacher = await prisma.teacher.findUnique({
    where: {
      userId: session.user.id,
    },
    include: {
      user: {
        select: {
          email: true,
          profileCompleted: true,
        },
      },
    },
  });

  if (!teacher) {
    return (
      <main className="min-h-screen bg-slate-50 p-6">
        <div className="mx-auto max-w-4xl rounded-xl border border-red-200 bg-white p-8">
          <h1 className="text-xl font-semibold text-red-700">
            Teacher Profile Not Found
          </h1>

          <p className="mt-2 text-sm text-slate-600">
            Your teacher account exists, but your teacher profile could not
            be found. Please contact the administrator.
          </p>
        </div>
      </main>
    );
  }

  if (!teacher.user.profileCompleted) {
    redirect("/teacher/setup");
  }

  if (!teacher.isActive) {
    return (
      <main className="min-h-screen bg-slate-50 p-6">
        <div className="mx-auto max-w-4xl rounded-xl border border-amber-200 bg-white p-8">
          <h1 className="text-xl font-semibold text-amber-700">
            Account Inactive
          </h1>

          <p className="mt-2 text-sm text-slate-600">
            Your teacher account is currently inactive. Please contact the
            school administrator.
          </p>
        </div>
      </main>
    );
  }

  const currentSession = await prisma.academicSession.findFirst({
    where: {
      isCurrent: true,
    },
    orderBy: {
      startDate: "desc",
    },
  });

  if (!currentSession) {
    return (
      <main className="min-h-screen bg-slate-50 p-6">
        <div className="mx-auto max-w-5xl">
          <div className="rounded-xl border border-slate-200 bg-white p-8">
            <h1 className="text-2xl font-semibold text-slate-900">
              Teacher Dashboard
            </h1>

            <p className="mt-2 text-sm text-slate-600">
              Welcome, {teacher.firstName} {teacher.lastName}.
            </p>

            <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
              No current academic session has been configured yet.
            </div>
          </div>
        </div>
      </main>
    );
  }

  const [subjectAssignments, classMasterAssignments] = await Promise.all([
    prisma.teacherAssignment.findMany({
      where: {
        teacherId: teacher.id,
        sessionId: currentSession.id,
      },
      include: {
        class: {
          select: {
            id: true,
            name: true,
            level: true,
            arm: true,
            stream: true,
            section: true,
          },
        },
        subject: {
          select: {
            id: true,
            name: true,
            code: true,
            section: true,
          },
        },
      },
      orderBy: [
        {
          class: {
            name: "asc",
          },
        },
        {
          subject: {
            name: "asc",
          },
        },
      ],
    }),

    prisma.classMasterAssignment.findMany({
      where: {
        teacherId: teacher.id,
        sessionId: currentSession.id,
      },
      include: {
        class: {
          include: {
            classSubjects: {
              include: {
                subject: {
                  select: {
                    id: true,
                    name: true,
                    code: true,
                  },
                },
              },
              orderBy: {
                subject: {
                  name: "asc",
                },
              },
            },
          },
        },
      },
      orderBy: {
        class: {
          name: "asc",
        },
      },
    }),
  ]);

  /*
   * Lower-school classes are determined entirely by
   * ClassMasterAssignment.
   *
   * We deliberately do NOT look at TeacherAssignment here.
   */
  const lowerClassAssignments = classMasterAssignments.filter((assignment) =>
    isLowerSchool(assignment.class.section),
  );

  /*
   * JSS / SS subject assignments only.
   */
  const subjectTeacherAssignments = subjectAssignments.filter(
    (assignment) => !isLowerSchool(assignment.class.section),
  );

  const lowerClasses = lowerClassAssignments.map((assignment) => ({
    id: assignment.class.id,
    name: assignment.class.name,
    level: assignment.class.level,
    arm: assignment.class.arm,
    stream: assignment.class.stream,
    section: assignment.class.section,
    subjects: assignment.class.classSubjects.map((classSubject) => ({
      id: classSubject.subject.id,
      name: classSubject.subject.name,
      code: classSubject.subject.code,
    })),
  }));

  /*
   * Count every class the teacher is actually responsible for.
   */
  const uniqueClassIds = new Set([
    ...subjectAssignments.map((assignment) => assignment.class.id),
    ...classMasterAssignments.map((assignment) => assignment.class.id),
  ]);

  const uniqueSubjectCount = new Set(
    subjectTeacherAssignments.map((assignment) => assignment.subject.id),
  ).size;

  const totalRoles =
    lowerClassAssignments.length +
    subjectTeacherAssignments.length +
    classMasterAssignments.filter(
      (assignment) => !isLowerSchool(assignment.class.section),
    ).length;

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-7xl px-6 py-8">
        <div className="mb-8 flex flex-col gap-4 border-b border-slate-200 pb-6 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">
              RISING FOUNDATION ACADEMY
            </p>

            <h1 className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">
              Teacher Dashboard
            </h1>

            <p className="mt-1 text-sm text-slate-600">
              Welcome, {teacher.firstName} {teacher.lastName}
            </p>
          </div>

          <div className="rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm">
            <p className="font-medium text-slate-800">
              {currentSession.name}
            </p>

            <p className="text-slate-500">Current Academic Session</p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="text-sm text-slate-500">My Classes</p>

            <p className="mt-2 text-3xl font-semibold text-slate-900">
              {uniqueClassIds.size}
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="text-sm text-slate-500">My Subjects</p>

            <p className="mt-2 text-3xl font-semibold text-slate-900">
              {uniqueSubjectCount}
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="text-sm text-slate-500">Form / Class Master</p>

            <p className="mt-2 text-3xl font-semibold text-slate-900">
              {classMasterAssignments.length}
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="text-sm text-slate-500">Active Roles</p>

            <p className="mt-2 text-3xl font-semibold text-slate-900">
              {totalRoles}
            </p>
          </div>
        </div>

        {lowerClasses.length > 0 && (
          <section className="mt-8">
            <div className="mb-4">
              <h2 className="text-lg font-semibold text-slate-900">
                My Classes
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                Lower-school classes where you are the Class Teacher.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {lowerClasses.map((classItem) => (
                <div
                  key={classItem.id}
                  className="rounded-xl border border-slate-200 bg-white p-6"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                        Class Teacher
                      </p>

                      <h3 className="mt-1 text-xl font-semibold text-slate-900">
                        {getClassLabel(classItem)}
                      </h3>
                    </div>

                    <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700">
                      {classItem.section}
                    </span>
                  </div>

                  <div className="mt-5 border-t border-slate-100 pt-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-500">Subjects</span>

                      <span className="font-medium text-slate-800">
                        {classItem.subjects.length}
                      </span>
                    </div>

                    <p className="mt-3 text-xs leading-5 text-slate-500">
                      You can enter complete student results for all subjects
                      in this class.
                    </p>
                  </div>

                  <div className="mt-5">
                    <Link
                      href={`/teacher/class/${classItem.id}`}
                      className="block w-full rounded-lg bg-slate-900 px-4 py-2.5 text-center text-sm font-medium text-white transition hover:bg-slate-800"
                    >
                      Open Class
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {subjectTeacherAssignments.length > 0 && (
          <section className="mt-8">
            <div className="mb-4">
              <h2 className="text-lg font-semibold text-slate-900">
                My Subjects
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                JSS and Senior Secondary subjects assigned to you.
              </p>
            </div>

            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="border-b border-slate-200 bg-slate-50">
                    <tr>
                      <th className="px-5 py-3 font-semibold text-slate-700">
                        Class
                      </th>

                      <th className="px-5 py-3 font-semibold text-slate-700">
                        Subject
                      </th>

                      <th className="px-5 py-3 font-semibold text-slate-700">
                        Term
                      </th>

                      <th className="px-5 py-3 text-right font-semibold text-slate-700">
                        Action
                      </th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-100">
                    {subjectTeacherAssignments.map((assignment) => (
                      <tr key={assignment.id}>
                        <td className="px-5 py-4">
                          <p className="font-medium text-slate-900">
                            {getClassLabel(assignment.class)}
                          </p>

                          <p className="text-xs text-slate-500">
                            {assignment.class.section}
                          </p>
                        </td>

                        <td className="px-5 py-4">
                          <p className="font-medium text-slate-900">
                            {assignment.subject.name}
                          </p>

                          <p className="text-xs text-slate-500">
                            {assignment.subject.code}
                          </p>
                        </td>

                        <td className="px-5 py-4 text-slate-700">
                          {assignment.term}
                        </td>

                        <td className="px-5 py-4 text-right">
                          <Link
                            href={`/teacher/results?assignmentId=${assignment.id}`}
                            className="inline-flex rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                          >
                            Enter Results
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}

        {classMasterAssignments.filter(
          (assignment) => !isLowerSchool(assignment.class.section),
        ).length > 0 && (
          <section className="mt-8">
            <div className="mb-4">
              <h2 className="text-lg font-semibold text-slate-900">
                My Form Classes
              </h2>

              <p className="mt-1 text-sm text-slate-500">
                JSS and Senior Secondary classes where you are the Form
                Master.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {classMasterAssignments
                .filter(
                  (assignment) =>
                    !isLowerSchool(assignment.class.section),
                )
                .map((assignment) => (
                  <div
                    key={assignment.id}
                    className="rounded-xl border border-slate-200 bg-white p-6"
                  >
                    <p className="text-xs font-medium uppercase tracking-wide text-slate-500">
                      Form Master
                    </p>

                    <h3 className="mt-1 text-xl font-semibold text-slate-900">
                      {getClassLabel(assignment.class)}
                    </h3>

                    <p className="mt-2 text-sm text-slate-500">
                      {assignment.class.section} · {currentSession.name}
                    </p>

                    <div className="mt-5">
                      <Link
                        href={`/teacher/class/${assignment.class.id}`}
                        className="block w-full rounded-lg border border-slate-300 px-4 py-2.5 text-center text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                      >
                        Open Form Class
                      </Link>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}

        {subjectAssignments.length === 0 &&
          classMasterAssignments.length === 0 && (
            <div className="mt-8 rounded-xl border border-slate-200 bg-white p-8 text-center">
              <h2 className="text-lg font-semibold text-slate-900">
                No assignments yet
              </h2>

              <p className="mx-auto mt-2 max-w-lg text-sm text-slate-500">
                Your administrator has not assigned you a class, subject,
                or form class for the current academic session.
              </p>
            </div>
          )}

        <div className="mt-8 rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-sm font-medium text-slate-800">
            Current session: {currentSession.name}
          </p>

          <p className="mt-1 text-sm text-slate-500">
            Your available classes, subjects, and form-master
            responsibilities are determined by the assignments made by the
            school administrator.
          </p>
        </div>
      </div>
    </main>
  );
}