"use client";

import { useRef, useState } from "react";

type TeacherSetupFormProps = {
  teacher: {
    firstName: string;
    lastName: string;
    staffNo: string;
    email: string;
  };
};

export default function TeacherSetupForm({
  teacher,
}: TeacherSetupFormProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [hasSignature, setHasSignature] = useState(false);
  const [drawing, setDrawing] = useState(false);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const getCanvasPoint = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ) => {
    const canvas = canvasRef.current;

    if (!canvas) {
      return { x: 0, y: 0 };
    }

    const rect = canvas.getBoundingClientRect();

    return {
      x:
        (event.clientX - rect.left) *
        (canvas.width / rect.width),
      y:
        (event.clientY - rect.top) *
        (canvas.height / rect.height),
    };
  };

  const startDrawing = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ) => {
    const canvas = canvasRef.current;

    if (!canvas) {
      return;
    }

    canvas.setPointerCapture(event.pointerId);

    const context = canvas.getContext("2d");

    if (!context) {
      return;
    }

    const point = getCanvasPoint(event);

    context.beginPath();
    context.moveTo(point.x, point.y);

    context.lineWidth = 3;
    context.lineCap = "round";
    context.lineJoin = "round";
    context.strokeStyle = "#111827";

    setDrawing(true);
    setHasSignature(true);
  };

  const draw = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ) => {
    if (!drawing) {
      return;
    }

    const canvas = canvasRef.current;

    if (!canvas) {
      return;
    }

    const context = canvas.getContext("2d");

    if (!context) {
      return;
    }

    const point = getCanvasPoint(event);

    context.lineTo(point.x, point.y);
    context.stroke();
  };

  const stopDrawing = (
    event: React.PointerEvent<HTMLCanvasElement>,
  ) => {
    const canvas = canvasRef.current;

    if (canvas?.hasPointerCapture(event.pointerId)) {
      canvas.releasePointerCapture(event.pointerId);
    }

    setDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;

    if (!canvas) {
      return;
    }

    const context = canvas.getContext("2d");

    if (!context) {
      return;
    }

    context.clearRect(0, 0, canvas.width, canvas.height);

    setHasSignature(false);
    setError("");
  };

  const handleSubmit = async (
    event: React.FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();

    setError("");

    if (password.length < 8) {
      setError(
        "Your new password must contain at least 8 characters.",
      );
      return;
    }

    if (password !== confirmPassword) {
      setError("The passwords do not match.");
      return;
    }

    if (!hasSignature) {
      setError("Please provide your signature.");
      return;
    }

    const canvas = canvasRef.current;

    if (!canvas) {
      setError("Unable to read your signature.");
      return;
    }

    const signatureData = canvas.toDataURL("image/png");

    setSaving(true);

    try {
      const response = await fetch("/api/teacher/setup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          password,
          signatureData,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Unable to complete account setup.",
        );
      }

      window.location.href = "/teacher";
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "An unexpected error occurred.",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-2xl border border-gray-200 bg-white shadow-sm"
    >
      <div className="border-b border-gray-200 px-6 py-5">
        <h2 className="text-lg font-bold text-gray-950">
          Teacher Information
        </h2>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              Name
            </p>

            <p className="mt-1 font-semibold text-gray-900">
              {teacher.firstName} {teacher.lastName}
            </p>
          </div>

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              Staff Number
            </p>

            <p className="mt-1 font-semibold text-gray-900">
              {teacher.staffNo}
            </p>
          </div>

          <div className="sm:col-span-2">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-400">
              Email
            </p>

            <p className="mt-1 font-semibold text-gray-900">
              {teacher.email}
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-8 px-6 py-6">
        <div>
          <h3 className="font-bold text-gray-950">
            Create Your Password
          </h3>

          <p className="mt-1 text-sm text-gray-500">
            Choose a password you will use for future teacher portal
            logins.
          </p>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-semibold text-gray-700">
                New Password
              </label>

              <input
                type="password"
                value={password}
                onChange={(event) =>
                  setPassword(event.target.value)
                }
                minLength={8}
                required
                autoComplete="new-password"
                placeholder="At least 8 characters"
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-900 focus:ring-2 focus:ring-gray-200"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-gray-700">
                Confirm Password
              </label>

              <input
                type="password"
                value={confirmPassword}
                onChange={(event) =>
                  setConfirmPassword(event.target.value)
                }
                minLength={8}
                required
                autoComplete="new-password"
                placeholder="Repeat your password"
                className="w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-gray-900 focus:ring-2 focus:ring-gray-200"
              />
            </div>
          </div>
        </div>

        <div>
          <div className="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h3 className="font-bold text-gray-950">
                Your Signature
              </h3>

              <p className="mt-1 text-sm text-gray-500">
                Draw your signature below. It will be saved to your teacher
                profile and used on your result sheets.
              </p>
            </div>

            <button
              type="button"
              onClick={clearSignature}
              className="w-fit text-sm font-semibold text-gray-600 hover:text-gray-950"
            >
              Clear Signature
            </button>
          </div>

          <div className="mt-4 overflow-hidden rounded-xl border border-gray-300 bg-white">
            <canvas
              ref={canvasRef}
              width={1000}
              height={300}
              onPointerDown={startDrawing}
              onPointerMove={draw}
              onPointerUp={stopDrawing}
              onPointerCancel={stopDrawing}
              className="h-56 w-full touch-none cursor-crosshair"
            />
          </div>

          <p className="mt-2 text-xs text-gray-400">
            Use your mouse, trackpad, touchscreen, or stylus to sign.
          </p>
        </div>

        {error && (
          <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full rounded-xl bg-gray-900 px-5 py-3.5 text-sm font-bold text-white hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {saving
            ? "Completing Setup..."
            : "Complete Teacher Setup"}
        </button>

        <p className="text-center text-xs leading-5 text-gray-400">
          You must complete this setup before accessing your teacher
          dashboard.
        </p>
      </div>
    </form>
  );
}