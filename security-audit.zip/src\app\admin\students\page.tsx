import Link from "next/link";
import { prisma } from "@/lib/prisma";
import DeleteStudentButton from "./DeleteStudentButton";

function Icon({
  name,
}: {
  name:
    | "dashboard"
    | "students"
    | "teachers"
    | "classes"
    | "subjects"
    | "enrollment"
    | "results"
    | "pin"
    | "assignments";
}) {
  const common = {
    width: 20,
    height: 20,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };

  if (name === "dashboard") {
    return (
      <svg {...common}>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </svg>
    );
  }

  if (name === "students") {
    return (
      <svg {...common}>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    );
  }

  if (name === "teachers") {
    return (
      <svg {...common}>
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
        <path d="M8 6h8" />
        <path d="M8 10h8" />
        <path d="M8 14h5" />
      </svg>
    );
  }

  if (name === "classes") {
    return (
      <svg {...common}>
        <path d="M3 21h18" />
        <path d="M5 21V7l7-4 7 4v14" />
        <path d="M9 21v-5h6v5" />
        <path d="M9 10h.01" />
        <path d="M15 10h.01" />
      </svg>
    );
  }

  if (name === "subjects") {
    return (
      <svg {...common}>
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
        <path d="M8 6h8" />
        <path d="M8 10h8" />
        <path d="M8 14h5" />
      </svg>
    );
  }

  if (name === "enrollment") {
    return (
      <svg {...common}>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <line x1="19" y1="8" x2="19" y2="14" />
        <line x1="16" y1="11" x2="22" y2="11" />
      </svg>
    );
  }

  if (name === "results") {
    return (
      <svg {...common}>
        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
        <path d="M8 7h8" />
        <path d="M8 11h8" />
        <path d="M8 15h5" />
      </svg>
    );
  }

  if (name === "pin") {
    return (
      <svg {...common}>
        <path d="M12 17v5" />
        <path d="M5 3h14" />
        <path d="M7 3v6l-2 4h14l-2-4V3" />
        <path d="M8 13h8" />
      </svg>
    );
  }

  return (
    <svg {...common}>
      <path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10Z" />
      <path d="M8 8h8" />
      <path d="M8 12h5" />
    </svg>
  );
}

const navigation = [
  {
    label: "Dashboard",
    href: "/admin",
    icon: "dashboard" as const,
  },
  {
    label: "Students",
    href: "/admin/students",
    icon: "students" as const,
  },
  {
    label: "Teachers",
    href: "/admin/teachers",
    icon: "teachers" as const,
  },
  {
    label: "Classes",
    href: "/admin/classes",
    icon: "classes" as const,
  },
  {
    label: "Subjects",
    href: "/admin/subjects",
    icon: "subjects" as const,
  },
  {
    label: "Enrollment",
    href: "/admin/enrollments/new",
    icon: "enrollment" as const,
  },
  {
    label: "Results",
    href: "/admin/results",
    icon: "results" as const,
  },
  {
    label: "Result PINs",
    href: "/admin/result-pins",
    icon: "pin" as const,
  },
  {
    label: "Assignments",
    href: "/admin/assignments",
    icon: "assignments" as const,
  },
];

export default async function StudentsPage() {
  const students = await prisma.student.findMany({
    orderBy: [{ lastName: "asc" }, { firstName: "asc" }],
    include: {
      enrollments: {
        include: {
          class: true,
          session: true,
        },
        orderBy: { createdAt: "desc" },
        take: 1,
      },
    },
  });

  const totalStudents = students.length;

  const activeStudents = students.filter(
    (student) => student.isActive,
  ).length;

  const inactiveStudents = totalStudents - activeStudents;

  return (
    <main className="min-h-screen bg-gray-50">
      <div className="flex min-h-screen">
        <aside className="hidden w-64 shrink-0 border-r border-gray-200 bg-white lg:flex lg:flex-col">
          <div className="flex h-[76px] items-center border-b border-gray-200 px-6">
            <div>
              <p className="text-[15px] font-bold tracking-tight text-gray-950">
                RISING FOUNDATION
              </p>

              <p className="mt-0.5 text-[11px] font-medium tracking-[0.18em] text-gray-500">
                ACADEMY
              </p>
            </div>
          </div>

          <nav className="flex-1 px-3 py-5">
            <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-gray-400">
              Main Menu
            </p>

            <div className="space-y-1">
              {navigation.map((item) => {
                const active = item.href === "/admin/students";

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                      active
                        ? "bg-gray-900 text-white shadow-sm"
                        : "text-gray-600 hover:bg-gray-100 hover:text-gray-950"
                    }`}
                  >
                    <span
                      className={`flex h-8 w-8 items-center justify-center rounded-md ${
                        active
                          ? "bg-white/10 text-white"
                          : "text-gray-500 group-hover:text-gray-900"
                      }`}
                    >
                      <Icon name={item.icon} />
                    </span>

                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </nav>

          <div className="border-t border-gray-200 p-4">
            <div className="flex items-center gap-3 rounded-lg bg-gray-50 px-3 py-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-900 text-xs font-bold text-white">
                A
              </div>

              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-gray-900">
                  Administrator
                </p>

                <p className="text-xs text-gray-500">
                  System Admin
                </p>
              </div>
            </div>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="border-b border-gray-200 bg-white">
            <div className="flex min-h-[76px] items-center justify-between px-6 py-4 lg:px-8">
              <div>
                <p className="mb-1 text-xs font-medium text-gray-500">
                  Administration
                </p>

                <h1 className="text-2xl font-bold tracking-tight text-gray-950">
                  Students
                </h1>
              </div>

              <Link
                href="/admin/students/new"
                className="rounded-lg bg-gray-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-gray-800"
              >
                + Add Student
              </Link>
            </div>
          </header>

          <div className="mx-auto max-w-7xl px-6 py-8 lg:px-8">
            <div className="mb-7">
              <h2 className="text-xl font-bold text-gray-950">
                Student Management
              </h2>

              <p className="mt-1 text-sm text-gray-500">
                Manage student records and enrollment information.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-3">
              <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-gray-400">
                  Total Students
                </p>

                <p className="mt-3 text-3xl font-bold text-gray-950">
                  {totalStudents}
                </p>
              </div>

              <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-gray-400">
                  Active Students
                </p>

                <p className="mt-3 text-3xl font-bold text-gray-950">
                  {activeStudents}
                </p>
              </div>

              <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
                <p className="text-[11px] font-bold uppercase tracking-[0.12em] text-gray-400">
                  Inactive Students
                </p>

                <p className="mt-3 text-3xl font-bold text-gray-950">
                  {inactiveStudents}
                </p>
              </div>
            </div>

            <div className="mt-7 overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
              <div className="border-b border-gray-200 px-6 py-5">
                <h3 className="text-base font-bold text-gray-950">
                  Student Directory
                </h3>

                <p className="mt-1 text-sm text-gray-500">
                  View and manage registered students.
                </p>
              </div>

              {students.length === 0 ? (
                <div className="px-6 py-12 text-center">
                  <p className="text-sm text-gray-500">
                    No students have been added yet.
                  </p>

                  <Link
                    href="/admin/students/new"
                    className="mt-4 inline-flex rounded-lg bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                  >
                    Add First Student
                  </Link>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-bold uppercase tracking-[0.08em] text-gray-500">
                          Admission No.
                        </th>

                        <th className="px-6 py-3 text-left text-xs font-bold uppercase tracking-[0.08em] text-gray-500">
                          Student
                        </th>

                        <th className="px-6 py-3 text-left text-xs font-bold uppercase tracking-[0.08em] text-gray-500">
                          Gender
                        </th>

                        <th className="px-6 py-3 text-left text-xs font-bold uppercase tracking-[0.08em] text-gray-500">
                          Class
                        </th>

                        <th className="px-6 py-3 text-left text-xs font-bold uppercase tracking-[0.08em] text-gray-500">
                          Status
                        </th>

                        <th className="px-6 py-3 text-right text-xs font-bold uppercase tracking-[0.08em] text-gray-500">
                          Action
                        </th>
                      </tr>
                    </thead>

                    <tbody className="divide-y divide-gray-100 bg-white">
                      {students.map((student) => {
                        const enrollment = student.enrollments[0];

                        const studentName = [
                          student.firstName,
                          student.middleName,
                          student.lastName,
                        ]
                          .filter(Boolean)
                          .join(" ");

                        return (
                          <tr
                            key={student.id}
                            className="transition hover:bg-gray-50"
                          >
                            <td className="whitespace-nowrap px-6 py-4 text-sm font-semibold text-gray-900">
                              {student.admissionNo}
                            </td>

                            <td className="whitespace-nowrap px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full bg-gray-100 text-xs font-semibold text-gray-500">
                                  {student.photoData ? (
                                    <img
                                      src={student.photoData}
                                      alt={studentName}
                                      className="h-full w-full object-cover"
                                    />
                                  ) : (
                                    `${student.firstName
                                      .charAt(0)
                                      .toUpperCase()}${student.lastName
                                      .charAt(0)
                                      .toUpperCase()}`
                                  )}
                                </div>

                                <div>
                                  <p className="text-sm font-semibold text-gray-900">
                                    {studentName}
                                  </p>
                                </div>
                              </div>
                            </td>

                            <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                              {student.gender === "MALE"
                                ? "Male"
                                : "Female"}
                            </td>

                            <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                              {enrollment ? (
                                <>
                                  {enrollment.class.name}
                                  {enrollment.class.arm
                                    ? ` ${enrollment.class.arm}`
                                    : ""}
                                </>
                              ) : (
                                <span className="text-gray-400">
                                  Not enrolled
                                </span>
                              )}
                            </td>

                            <td className="whitespace-nowrap px-6 py-4">
                              {student.isActive ? (
                                <span className="inline-flex rounded-full bg-green-50 px-2.5 py-1 text-xs font-semibold text-green-700">
                                  Active
                                </span>
                              ) : (
                                <span className="inline-flex rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-600">
                                  Inactive
                                </span>
                              )}
                            </td>

                            <td className="whitespace-nowrap px-6 py-4">
                              <div className="flex items-center justify-end gap-3">
                                <Link
                                  href={`/admin/students/${student.id}`}
                                  className="text-sm font-semibold text-gray-700 hover:text-gray-950"
                                >
                                  View
                                </Link>

                                <Link
                                  href={`/admin/students/${student.id}/edit`}
                                  className="text-sm font-semibold text-gray-700 hover:text-gray-950"
                                >
                                  Edit
                                </Link>

                                {!enrollment && (
                                  <Link
                                    href="/admin/enrollments/new"
                                    className="text-sm font-semibold text-gray-700 hover:text-gray-950"
                                  >
                                    Enroll
                                  </Link>
                                )}

                                <DeleteStudentButton
                                  studentId={student.id}
                                  studentName={studentName}
                                />
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}